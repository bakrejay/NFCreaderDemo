package example.jllarraz.com.passportreader.common

object IntentData {

    val KEY_MRZ_INFO = "KEY_MRZ_INFO"
    val KEY_PASSPORT = "KEY_PASSPORT"
    val KEY_IMAGE = "KEY_IMAGE"
}
