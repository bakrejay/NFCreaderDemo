package example.jllarraz.com.passportreader.common

object PreferencesKeys {
    val KEY_OCR_ENGINE_MODE = "KEY_OCR_ENGINE_MODE"
    val KEY_CONTINUOUS_PREVIEW = "KEY_CONTINUOUS_PREVIEW"


}
